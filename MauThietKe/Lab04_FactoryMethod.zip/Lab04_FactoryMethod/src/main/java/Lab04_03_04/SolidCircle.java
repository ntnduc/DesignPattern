package Lab04_03_04;

public class SolidCircle implements IShape {

	public void draw() {
		// TODO Auto-generated method stub
		new drawSolidCircle();
	}

}
