package Lab04_03_04;

public class SolidRectangle implements IShape {

	public void draw() {
		// TODO Auto-generated method stub
		new drawSolidRect();
	}

}
