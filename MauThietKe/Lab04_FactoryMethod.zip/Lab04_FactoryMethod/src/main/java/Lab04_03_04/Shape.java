package Lab04_03_04;

public class Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DrawShape draw = new DrawShape();
		draw.draw(3, 2);
	}

}
