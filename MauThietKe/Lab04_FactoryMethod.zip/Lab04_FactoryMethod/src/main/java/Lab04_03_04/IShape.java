package Lab04_03_04;

public interface IShape {
	void draw();
}
