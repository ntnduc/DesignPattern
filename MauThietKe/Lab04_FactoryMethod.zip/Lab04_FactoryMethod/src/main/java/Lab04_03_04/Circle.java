package Lab04_03_04;
import java.awt.*;
import javax.swing.*;
public class Circle implements IShape{

	public void draw() {
		// TODO Auto-generated method stub
		new drawCircle();
	}
}

	