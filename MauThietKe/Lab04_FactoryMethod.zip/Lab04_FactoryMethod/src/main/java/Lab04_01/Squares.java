package Lab04_01;

public class Squares implements IShape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.print("Draw Squares");
	}

}
