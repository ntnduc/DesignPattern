package Lab04_01;

public class SolidRectangle implements IShape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.print("Draw Solid Reactangle");
	}

}
