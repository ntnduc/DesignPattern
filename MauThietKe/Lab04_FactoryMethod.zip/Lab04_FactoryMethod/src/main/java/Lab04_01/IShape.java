package Lab04_01;

public interface IShape {
	void draw();
}
