package Lab04_01;

public class SolidSquares implements IShape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.print("Draw Solid Square");
	}

}
