package Lab04_01;

public class Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DrawShape draw = new DrawShape();
		draw.draw(2, 2);
	}

}
