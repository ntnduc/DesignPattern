package Lab04_01;

public class SolidCircle implements IShape {

	public void draw() {
		// TODO Auto-generated method stub
		System.out.print("draw Solid Circle");
	}

}
