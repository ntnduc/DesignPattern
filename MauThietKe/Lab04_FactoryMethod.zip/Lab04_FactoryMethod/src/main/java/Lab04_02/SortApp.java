package Lab04_02;

public class SortApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedList test = new SortedList();
		test.add(9);
		test.add(8);
		test.add(1);
		test.add(3);
		test.add(5);
		
		test.printList();
	}

}
