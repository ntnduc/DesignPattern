package Lab02_01;

public interface ISortStrategy {
	public void sort (Student [] data, int count);
}