package Lab02_02;

public interface IValidation {
	public boolean validate (String data);

}
