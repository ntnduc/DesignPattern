package qlsv;

public class main {

	public static void main(String args[]) {
	Student _student1 = new Student(01, "Nguyen Tran Nhat Duc", 3);
	_student1.addCourse();
	_student1.Show();
		

	}

}
